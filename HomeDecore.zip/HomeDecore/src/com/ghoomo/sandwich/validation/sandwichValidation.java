package com.ghoomo.sandwich.validation;

import java.math.BigInteger;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.ghoomo.sandwich.constant.AppConstant;
import com.ghoomo.sandwich.dto.CustomerDto;
import com.ghoomo.sandwich.service.CustomerService;
import com.ghoomo.sandwich.utility.PropertiesUtil;

public class sandwichValidation {
	
	static Logger logger = Logger.getLogger(sandwichValidation.class);

	public static String customerValidation(CustomerDto customerInfo) {
		logger.info("********* VALIDATION customerValidation ****************");
		if (customerInfo.getName() == null
				|| customerInfo.getName().trim().length() == 0
				|| customerInfo.getName().trim().length() > 50) {
			return PropertiesUtil
					.getProperty(AppConstant.CUSTOMER_NAME_VALIDATION);

		}
		if (customerInfo.getMobile() == null
				|| customerInfo.getMobile().trim().length() < 10
				|| customerInfo.getMobile().trim().length() > 10) {
			return PropertiesUtil.getProperty(AppConstant.MOBILE_VALIDATION);
		}
		try {
			BigInteger bigInteger = new BigInteger(customerInfo.getMobile());

		} catch (NumberFormatException numberFormatException) {
			return PropertiesUtil.getProperty(AppConstant.MOBILE_VALIDATION);
		}

		if (customerInfo.getEmail() == null
				|| customerInfo.getEmail().trim().length() == 0
				|| customerInfo.getEmail().trim().length() > 100
				|| !(customerInfo.getEmail().matches(PropertiesUtil
						.getProperty(AppConstant.EMAIL_REJEX)))) {
			return PropertiesUtil.getProperty(AppConstant.EMAIL_VALIDATION);
		}
		if (customerInfo.getPassword() == null
				|| customerInfo.getPassword().trim().length() == 0
				|| customerInfo.getPassword().trim().length() < 6
				|| customerInfo.getPassword().trim().length() > 20) {
			return PropertiesUtil.getProperty(AppConstant.PASSWORD_VALIDATION);

		}
		
		return null;

	}

	public static String customerLoginValidation(CustomerDto customerInfo) {
		logger.info("********* VALIDATION customerLoginValidation ****************");
		if (customerInfo.getEmail() == null
				|| customerInfo.getEmail().trim().length() == 0) {
			return PropertiesUtil.getProperty(AppConstant.BLANK_LOGIN_ID);
		}
		if (customerInfo.getPassword() == null
				|| customerInfo.getPassword().trim().length() == 0) {
			return PropertiesUtil.getProperty(AppConstant.BLANK_LOGIN_PASSWORD);
		}

		return null;
	}
	
	
}
