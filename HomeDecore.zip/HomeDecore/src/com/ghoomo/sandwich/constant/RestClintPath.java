package com.ghoomo.sandwich.constant;

public class RestClintPath {

	public final static String MANAGE_USER = "manageUser";
	public final static String MANAGE_FOOD_SERVICE = "manageFoodService";
	public final static String CREATE_CUSTOMER = "createCustomer";
	public final static String LOGIN_CUSTOMER = "loginCustomer";
	public final static String GET_CATEGORY = "getCategory";
	public final static String GET_ITEM_FOR_CATEGORY = "getItemForCategory";
	public final static String CSC = "csc";
	public final static String GET_COUNTRY = "getCountry";
	public final static String GET_STATE = "getState";
	public final static String GET_CITY = "getCity";
}
