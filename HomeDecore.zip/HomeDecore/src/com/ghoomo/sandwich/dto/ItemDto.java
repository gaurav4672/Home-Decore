package com.ghoomo.sandwich.dto;

public class ItemDto {
	
	private int itemId;
	private String itemName;
	private float itemPrice;
	private double itemWeight;
	private double itemCalories;
	private int isVeg;
	private String itemImage;
	/**
	 * @return the itemId
	 */
	public int getItemId() {
		return itemId;
	}
	/**
	 * @param itemId the itemId to set
	 */
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	/**
	 * @return the itemName
	 */
	public String getItemName() {
		return itemName;
	}
	/**
	 * @param itemName the itemName to set
	 */
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	/**
	 * @return the itemPrice
	 */
	public float getItemPrice() {
		return itemPrice;
	}
	/**
	 * @param itemPrice the itemPrice to set
	 */
	public void setItemPrice(float itemPrice) {
		this.itemPrice = itemPrice;
	}
	/**
	 * @return the itemWeight
	 */
	public double getItemWeight() {
		return itemWeight;
	}
	/**
	 * @param itemWeight the itemWeight to set
	 */
	public void setItemWeight(double itemWeight) {
		this.itemWeight = itemWeight;
	}
	/**
	 * @return the itemCalories
	 */
	public double getItemCalories() {
		return itemCalories;
	}
	/**
	 * @param itemCalories the itemCalories to set
	 */
	public void setItemCalories(double itemCalories) {
		this.itemCalories = itemCalories;
	}
	
	/**
	 * @return the itemImage
	 */
	public String getItemImage() {
		return itemImage;
	}
	/**
	 * @param itemImage the itemImage to set
	 */
	public void setItemImage(String itemImage) {
		this.itemImage = itemImage;
	}
	/**
	 * @return the isVeg
	 */
	public int getIsVeg() {
		return isVeg;
	}
	/**
	 * @param isVeg the isVeg to set
	 */
	public void setIsVeg(int isVeg) {
		this.isVeg = isVeg;
	}
	
	
	
	

}
