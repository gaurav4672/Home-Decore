package com.ghoomo.sandwich.restservice;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ghoomo.sandwich.constant.AppConstant;
import com.ghoomo.sandwich.constant.RestClintPath;
import com.ghoomo.sandwich.dto.CSCDto;
import com.ghoomo.sandwich.dto.Response;
import com.ghoomo.sandwich.service.CustomerService;
import com.ghoomo.sandwich.utility.PropertiesUtil;

@Service
@Path(RestClintPath.CSC)
public class CSCRestService {
	
	static Logger logger = Logger.getLogger(CSCRestService.class);
	
	@Autowired
	private CustomerService customerService;
	
	@GET
	@Path(RestClintPath.GET_COUNTRY)
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	public Object getCountry(@Context HttpServletRequest request) {
		logger.info("********* API getCountry ****************");
//		CustomerDto customerInfo=(CustomerDto)request.getAttribute(AppConstant.LOGIN_CUSTOMER);
		List<CSCDto> countryList=customerService.getCountryList();
		if(countryList==null || countryList.size()==0){
			Response response=new Response();
			response.setResponse(PropertiesUtil
					.getProperty(AppConstant.DATA_NOT_FOUND_RESPONSE_MESSAGE));
			response.setResponseCode(PropertiesUtil
					.getProperty(AppConstant.DATA_NOT_FOUND_RESPONSE_CODE));
			return response;
		}
		return countryList;
		
	}
	
	@GET
	@Path(RestClintPath.GET_STATE)
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	public Object getStateList(@Context HttpServletRequest request,@QueryParam("countryId") int countryId) {
		logger.info("********* API getStateList ****************");
//		CustomerDto customerInfo=(CustomerDto)request.getAttribute(AppConstant.LOGIN_CUSTOMER);
		List<CSCDto> stateList=customerService.getStateListCorrespondingToCountry(countryId);
		if(stateList==null || stateList.size()==0){
			Response response=new Response();
			response.setResponse(PropertiesUtil
					.getProperty(AppConstant.DATA_NOT_FOUND_RESPONSE_MESSAGE));
			response.setResponseCode(PropertiesUtil
					.getProperty(AppConstant.DATA_NOT_FOUND_RESPONSE_CODE));
			return response;
		}
		return stateList;
		
	}
	
	@GET
	@Path(RestClintPath.GET_CITY)
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	public Object getCityList(@Context HttpServletRequest request,@QueryParam("stateId") int stateId) {
		logger.info("********* API getCityList ****************");
//		CustomerDto customerInfo=(CustomerDto)request.getAttribute(AppConstant.LOGIN_CUSTOMER);
		List<CSCDto> cityList=customerService.getCityListCorrespondingToState(stateId);
		if(cityList==null || cityList.size()==0){
			Response response=new Response();
			response.setResponse(PropertiesUtil
					.getProperty(AppConstant.DATA_NOT_FOUND_RESPONSE_MESSAGE));
			response.setResponseCode(PropertiesUtil
					.getProperty(AppConstant.DATA_NOT_FOUND_RESPONSE_CODE));
			return response;
		}
		return cityList;
		
	}
}
