package com.ghoomo.sandwich.restservice;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ghoomo.sandwich.constant.AppConstant;
import com.ghoomo.sandwich.constant.RestClintPath;
import com.ghoomo.sandwich.dto.CategoryDto;
import com.ghoomo.sandwich.dto.CustomerDto;
import com.ghoomo.sandwich.dto.ItemDto;
import com.ghoomo.sandwich.dto.OwnerInfo;
import com.ghoomo.sandwich.dto.Response;
import com.ghoomo.sandwich.service.FoodService;
import com.ghoomo.sandwich.utility.PropertiesUtil;

@Service
@Path(RestClintPath.MANAGE_FOOD_SERVICE)
public class FoodManageRestService {
	
	static Logger logger = Logger.getLogger(FoodManageRestService.class);
	
	@Autowired
	private FoodService foodService;

	@GET
	@Path(RestClintPath.GET_CATEGORY)
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	public Object getCategory(@Context HttpServletRequest request) {
		logger.info("********* API createCustomer ****************");
		CustomerDto customerInfo=(CustomerDto)request.getAttribute(AppConstant.LOGIN_CUSTOMER);
		List<CategoryDto> categoryList=foodService.getCategoryList();
		if(categoryList==null || categoryList.size()==0){
			Response response=new Response();
			response.setResponse(PropertiesUtil.getProperty(AppConstant.DATA_NOT_FOUND_RESPONSE_MESSAGE));
			response.setResponseCode(PropertiesUtil
					.getProperty(AppConstant.DATA_NOT_FOUND_RESPONSE_CODE));
			return response;
		}
		return categoryList;
		
	}
	
	@GET
	@Path(RestClintPath.GET_ITEM_FOR_CATEGORY)
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	public Object getItemForCategory(@Context HttpServletRequest request,@QueryParam("categoryId") int categoryId) {
		logger.info("********* API getItemForCategory ****************");
		CustomerDto customerInfo=(CustomerDto)request.getAttribute(AppConstant.LOGIN_CUSTOMER);
		List<ItemDto> itemListAccordingToCategoryId=foodService.getItemListAccordingToCategoryId(categoryId);
		if(itemListAccordingToCategoryId==null || itemListAccordingToCategoryId.size()==0){
			Response response=new Response();
			response.setResponse(PropertiesUtil.getProperty(AppConstant.DATA_NOT_FOUND_RESPONSE_MESSAGE));
			response.setResponseCode(PropertiesUtil
					.getProperty(AppConstant.DATA_NOT_FOUND_RESPONSE_CODE));
			return response;
		}
		return itemListAccordingToCategoryId;
		
	}

	
}
