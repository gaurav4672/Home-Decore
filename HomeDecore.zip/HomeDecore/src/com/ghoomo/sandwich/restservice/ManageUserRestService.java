package com.ghoomo.sandwich.restservice;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ghoomo.sandwich.constant.AppConstant;
import com.ghoomo.sandwich.constant.RestClintPath;
import com.ghoomo.sandwich.dto.CustomerDto;
import com.ghoomo.sandwich.dto.Response;
import com.ghoomo.sandwich.service.CustomerService;
import com.ghoomo.sandwich.utility.PropertiesUtil;
import com.ghoomo.sandwich.utility.TokenUtility;
import com.ghoomo.sandwich.validation.sandwichValidation;

@Service
@Path(RestClintPath.MANAGE_USER)
public class ManageUserRestService {
	static Logger logger = Logger.getLogger(ManageUserRestService.class);

	@Autowired
	private CustomerService customerService;

	@POST
	@Path(RestClintPath.CREATE_CUSTOMER)
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	public Response createCustomer(CustomerDto customerInfo) {
		logger.info("********* API createCustomer ****************");
		Response response = new Response();
		String validationResult = sandwichValidation
				.customerValidation(customerInfo);
		if (validationResult != null) {
			response.setResponse(validationResult);
			response.setResponseCode(PropertiesUtil
					.getProperty(AppConstant.VALIDATION_FAILED_RESPONSE_CODE));
			return response;
		}
		
		if(customerService.isCountryExist(customerInfo.getCountryId())==0){
			response.setResponse(PropertiesUtil
					.getProperty(AppConstant.COUNTRY_VALIDATION));
			response.setResponseCode(PropertiesUtil
					.getProperty(AppConstant.VALIDATION_FAILED_RESPONSE_CODE));
			return response;
		}
		if(customerService.isStateExistCorrespondingToCountry(customerInfo.getCountryId(), customerInfo.getStateId())==0){
			response.setResponse(PropertiesUtil
					.getProperty(AppConstant.STATE_VALIDATION));
			response.setResponseCode(PropertiesUtil
					.getProperty(AppConstant.VALIDATION_FAILED_RESPONSE_CODE));
			return response;
		}
	
		if(customerService.isCityExistCorrespondingToState(customerInfo.getCityId(), customerInfo.getStateId())==0){
			response.setResponse(PropertiesUtil
					.getProperty(AppConstant.CITY_VALIDATION));
			response.setResponseCode(PropertiesUtil
					.getProperty(AppConstant.VALIDATION_FAILED_RESPONSE_CODE));
			return response;
		}
		
		int customerInsertionResult = customerService
				.customerInsertion(customerInfo);
		if (customerInsertionResult > 0) {
			response.setResponse(String.valueOf(customerInsertionResult));
			response.setResponseCode(PropertiesUtil
					.getProperty(AppConstant.COMPLETE_REQUEST_RESPONSE_CODE));
			return response;
		} else if (customerInsertionResult == -1) {
			response.setResponse(PropertiesUtil
					.getProperty(AppConstant.ACCOUNT_ALREADY_EXIST_MESSAGE));
			response.setResponseCode(PropertiesUtil
					.getProperty(AppConstant.VALIDATION_FAILED_RESPONSE_CODE));
			return response;
		} else {
			response.setResponse(PropertiesUtil
					.getProperty(AppConstant.INETERNAL_SERVER_ERROR_MESSAGE));
			response.setResponseCode(PropertiesUtil
					.getProperty(AppConstant.INETERNAL_SERVER_ERROR_CODE));
			return response;
		}
	}

	@POST
	@Path(RestClintPath.LOGIN_CUSTOMER)
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	public Object loginCustomer(CustomerDto customerInfo) {
		logger.info("********* API loginCustomer ****************");
		String customerLoginValidation = sandwichValidation
				.customerLoginValidation(customerInfo);
		Response response = new Response();
		if (customerLoginValidation != null) {
			response.setResponse(customerLoginValidation);
			response.setResponseCode(PropertiesUtil
					.getProperty(AppConstant.VALIDATION_FAILED_RESPONSE_CODE));
			return response;
		}
		CustomerDto customerDto = customerService.checkLoginAuth(customerInfo);
		if (customerDto == null || customerDto.getCustomerId() < 1) {
			response.setResponse(PropertiesUtil
					.getProperty(AppConstant.LOGIN_DETAILS_NOT_VALID_MESSAGE));
			response.setResponseCode(PropertiesUtil
					.getProperty(AppConstant.DATA_NOT_FOUND_RESPONSE_CODE));
			return response;
		}
		if (customerDto.getIsActive() == 0) {
			response.setResponse(PropertiesUtil
					.getProperty(AppConstant.CUSTOMER_DEACTIVATE_MESSAGE));
			response.setResponseCode(PropertiesUtil
					.getProperty(AppConstant.DATA_NOT_FOUND_RESPONSE_CODE));
			return response;
		}
		customerDto.setLoginToken(TokenUtility.createToken(customerDto));
		return customerDto;
	}

}
