package com.ghoomo.sandwich.dao;

import java.util.List;

import com.ghoomo.sandwich.dto.CSCDto;
import com.ghoomo.sandwich.dto.CustomerDto;

public interface CustomerDao {

	int customerInsertion(CustomerDto customerInfo) throws Exception;

	CustomerDto checkLoginAuth(CustomerDto customerInfo) throws Exception;

	int isCountryExist(int countryId) throws Exception;

	int isStateExistCorrespondingToCountry(int countryId, int stateId)
			throws Exception;

	int isCityExistCorrespondingToState(int cityId, int stateId)
			throws Exception;

	List<CSCDto> getCountryList() throws Exception;

	List<CSCDto> getStateListCorrespondingToCountry(int countryId) throws Exception;

	List<CSCDto> getCityListCorrespondingToState(int stateId) throws Exception;

}
