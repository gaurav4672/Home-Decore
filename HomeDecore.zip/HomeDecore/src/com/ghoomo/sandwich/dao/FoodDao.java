package com.ghoomo.sandwich.dao;

import java.util.List;

import com.ghoomo.sandwich.dto.Attachment;
import com.ghoomo.sandwich.dto.CategoryDto;
import com.ghoomo.sandwich.dto.ItemDto;
import com.ghoomo.sandwich.dto.OwnerInfo;

public interface FoodDao {

	List<CategoryDto> getCategoryList() throws Exception;

	List<ItemDto> getItemListAccordingToCategoryId(int categoryId)
			throws Exception;

	int insertOwnerRequirement(OwnerInfo ownerInfo) throws Exception;

	int insertOwnerRequirementAttachment(int ownerId,
			List<Attachment> attachmentList) throws Exception;

}
