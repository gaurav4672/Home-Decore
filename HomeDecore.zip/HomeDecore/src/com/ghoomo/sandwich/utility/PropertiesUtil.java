package com.ghoomo.sandwich.utility;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;


/**
 * This class loads all the property values from property files at the time of
 * server startup
 * 
 * @author Virendra
 * @version 1.0
 */
public class PropertiesUtil extends PropertyPlaceholderConfigurer {
	/**
	 * Map which contains properties and its values
	 */
	private static Map<String, String> propertiesMap;

	/**
	 * this method gets the key and value from properties file and set it to Map
	 */
	@Override
	protected void processProperties(
			ConfigurableListableBeanFactory beanFactory, Properties props)
			throws BeansException {
		super.processProperties(beanFactory, props);

		propertiesMap = new HashMap<String, String>();
		for (Object key : props.keySet()) {
			String keyStr = key.toString();
			propertiesMap.put(
					keyStr,
					parseStringValue(props.getProperty(keyStr), props,
							new HashSet()));
		}
	}

	/**
	 * gets the value of property corresponding to key
	 * 
	 * @param name
	 *            name of key
	 * @return value of key
	 */
	public static String getProperty(String name) {
		return propertiesMap.get(name);
	}
	
	
	
	
	
	
}
