package com.ghoomo.sandwich.utility;

import java.util.HashMap;
import java.util.Map;

import com.ghoomo.sandwich.dto.CustomerDto;

public class TokenUtility {
	static Map<String, CustomerDto> tokenMap = new HashMap<String, CustomerDto>();

	public static String createToken(CustomerDto user) {
		String token = java.util.UUID.randomUUID().toString();
		tokenMap.put(token, user);
		return token;
	}

	public static CustomerDto checkValidToken(String token) {
		CustomerDto user = tokenMap.get(token);
		return user;
	}

}
