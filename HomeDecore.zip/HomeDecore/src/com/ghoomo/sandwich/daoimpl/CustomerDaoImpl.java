package com.ghoomo.sandwich.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import com.ghoomo.sandwich.constant.AppConstant;
import com.ghoomo.sandwich.constant.AppQueryConstant;
import com.ghoomo.sandwich.dao.CustomerDao;
import com.ghoomo.sandwich.dto.CSCDto;
import com.ghoomo.sandwich.dto.CustomerDto;
import com.ghoomo.sandwich.serviceimpl.CustomerServiceImpl;
import com.ghoomo.sandwich.utility.PropertiesUtil;

public class CustomerDaoImpl implements CustomerDao {

	static Logger logger = Logger.getLogger(CustomerServiceImpl.class);

	private JdbcTemplate jdbcTemplate;

	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public int customerInsertion(final CustomerDto customerInfo)
			throws Exception {
		logger.info("********* DAO customerInsertion ****************");
		final String sql = PropertiesUtil
				.getProperty(AppQueryConstant.CUSTOMER_INSERTION);
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator() {
			public PreparedStatement createPreparedStatement(
					Connection connection) throws SQLException {
				PreparedStatement ps = connection.prepareStatement(sql,
						new String[] { "id" });
				ps.setString(1, customerInfo.getName().trim());
				ps.setString(2, customerInfo.getEmail().trim());
				ps.setString(3, customerInfo.getMobile().trim());
				ps.setString(4, customerInfo.getLandline());
				ps.setString(5, customerInfo.getPassword());
				ps.setInt(6, customerInfo.getCountryId());
				ps.setInt(7, customerInfo.getStateId());
				ps.setInt(8, customerInfo.getCityId());
				ps.setString(9, customerInfo.getAddress().trim());
				ps.setInt(10, customerInfo.getUserType());
				ps.setInt(11, customerInfo.getContExpYear());
				ps.setInt(12, customerInfo.getContExpMonth());
				ps.setString(13, customerInfo.getImage());
				ps.setString(14, customerInfo.getOrganizatonName());
				ps.setString(15, customerInfo.getAlternateNumber());
				ps.setInt(16, customerInfo.getSubscriptionId());
				ps.setString(17, customerInfo.getFcmToken());
				ps.setString(18, customerInfo.getPostalcode());
				return ps;
			}
		}, keyHolder);

		return keyHolder.getKey().intValue();
	}

	@Override
	public CustomerDto checkLoginAuth(CustomerDto customerInfo)
			throws Exception {
		logger.info("********* DAO checkLoginAuth ****************");
		logger.info("userName:::::::::::::" + customerInfo.getEmail());
		logger.info("Password:::::::::::::" + customerInfo.getPassword());
		String sql = PropertiesUtil
				.getProperty(AppQueryConstant.CHECK_LOGIN_AUTH);
		return jdbcTemplate.queryForObject(sql,
				new Object[] { customerInfo.getEmail(),
						customerInfo.getEmail(), customerInfo.getPassword() },
				new RowMapper<CustomerDto>() {

					@Override
					public CustomerDto mapRow(ResultSet rs, int arg1)
							throws SQLException {
						CustomerDto customerDto = new CustomerDto();
						customerDto.setCustomerId(rs.getInt("id"));
						customerDto.setName(rs.getString("name"));
						customerDto.setEmail(rs.getString("email"));
						customerDto.setMobile(rs.getString("mobile"));
						customerDto.setAddress(rs.getString("address"));
						customerDto.setCreateDateTime(rs
								.getString("create_date"));
						customerDto.setUpdateDateTime(rs
								.getString("update_date"));
						customerDto.setIsActive(rs.getInt("is_active"));
						if (rs.getString("profile_image") != null
								&& rs.getString("image").trim().length() > 0) {
							customerDto.setImage(PropertiesUtil
									.getProperty(AppConstant.IMAGE_URL)
									+ rs.getString("profile_image"));
						}
						customerDto.setLandline(rs.getString("landline"));
						customerDto.setCountryId(rs.getInt("country_id"));
						customerDto.setStateId(rs.getInt("state_id"));
						customerDto.setCityId(rs.getInt("city_id"));
						customerDto.setPostalcode(rs.getString("postal_code"));
						customerDto.setUserType(rs.getInt("user_type"));
						customerDto.setContExpYear(rs.getInt("cont_exp_year"));
						customerDto.setContExpMonth(rs.getInt("cont_exp_month"));
						customerDto.setOrganizatonName(rs.getString("organization_name"));
						customerDto.setIsDeleted(rs.getInt("is_deleted"));
						customerDto.setAlternateNumber(rs.getString("alternate_number"));
						customerDto.setSubscriptionId(rs.getInt("subcription_id"));
						customerDto.setFcmToken(rs.getString("fcm_token"));
						return customerDto;
					}

				});

	}

	@Override
	public int isCountryExist(int countryId) throws Exception {
		logger.info("********* DAO isCountryExist ****************");
		logger.info("countryId:::::::::::::" + countryId);
		String sql = PropertiesUtil
				.getProperty(AppQueryConstant.IS_COUNTRY_EXIST);
		return jdbcTemplate.queryForInt(sql, countryId);
	}

	@Override
	public int isStateExistCorrespondingToCountry(int countryId, int stateId)
			throws Exception {
		logger.info("********* DAO isStateExistCorrespondingToCountry ****************");
		logger.info("countryId:::::::::::::" + countryId);
		logger.info("stateId:::::::::::::" + stateId);
		String sql = PropertiesUtil
				.getProperty(AppQueryConstant.IS_STATE_EXIST_CORRESPONDING_TO_COUNTRY);
		return jdbcTemplate.queryForInt(sql, stateId, countryId);
	}

	@Override
	public int isCityExistCorrespondingToState(int cityId, int stateId)
			throws Exception {
		logger.info("********* DAO isCityExistCorrespondingToState ****************");
		logger.info("cityId:::::::::::::" + cityId);
		logger.info("stateId:::::::::::::" + stateId);
		String sql = PropertiesUtil
				.getProperty(AppQueryConstant.IS_CITY_EXIST_CORRESPONDING_TO_STATE);
		return jdbcTemplate.queryForInt(sql, cityId, stateId);
	}

	@Override
	public List<CSCDto> getCountryList() throws Exception {
		logger.info("********* DAO getCountryList ****************");
		String sql = PropertiesUtil
				.getProperty(AppQueryConstant.GET_COUNTRY_LIST);
		return jdbcTemplate.query(sql, new RowMapper<CSCDto>() {

			@Override
			public CSCDto mapRow(ResultSet rs, int arg1) throws SQLException {
				CSCDto cscDto = new CSCDto();
				cscDto.setCountryId(rs.getInt("id"));
				cscDto.setCountryName(rs.getString("name"));
				return cscDto;
			}

		});
	}

	@Override
	public List<CSCDto> getStateListCorrespondingToCountry(int countryId)
			throws Exception {
		logger.info("********* DAO getStateListCorrespondingToCountry ****************");
		String sql = PropertiesUtil
				.getProperty(AppQueryConstant.GET_STATE_LIST_CORRESPONDING_TO_COUNTRY);
		return jdbcTemplate.query(sql, new Object[] { countryId },
				new RowMapper<CSCDto>() {

					@Override
					public CSCDto mapRow(ResultSet rs, int arg1)
							throws SQLException {
						CSCDto cscDto = new CSCDto();
						cscDto.setStateId(rs.getInt("id"));
						cscDto.setStateName(rs.getString("name"));
						return cscDto;
					}

				});
	}

	@Override
	public List<CSCDto> getCityListCorrespondingToState(int stateId)
			throws Exception {
		logger.info("********* DAO getCityListCorrespondingToState ****************");
		String sql = PropertiesUtil
				.getProperty(AppQueryConstant.GET_CITY_LIST_CORRESPONDING_TO_STATE);
		return jdbcTemplate.query(sql, new Object[] { stateId },
				new RowMapper<CSCDto>() {

					@Override
					public CSCDto mapRow(ResultSet rs, int arg1)
							throws SQLException {
						CSCDto cscDto = new CSCDto();
						cscDto.setCityId(rs.getInt("id"));
						cscDto.setCityName(rs.getString("name"));
						return cscDto;
					}

				});
	}

}
