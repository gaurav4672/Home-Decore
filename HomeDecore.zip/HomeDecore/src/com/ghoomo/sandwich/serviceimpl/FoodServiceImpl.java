package com.ghoomo.sandwich.serviceimpl;

import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.ghoomo.sandwich.dao.FoodDao;
import com.ghoomo.sandwich.daoimpl.FoodDaoImpl;
import com.ghoomo.sandwich.dto.CategoryDto;
import com.ghoomo.sandwich.dto.ItemDto;
import com.ghoomo.sandwich.dto.OwnerInfo;
import com.ghoomo.sandwich.service.FoodService;

public class FoodServiceImpl implements FoodService {

	static Logger logger = Logger.getLogger(FoodServiceImpl.class);

	@Autowired
	private FoodDao foodDao;

	@Autowired
	private DataSource dataSource;

	@Override
	public List<CategoryDto> getCategoryList() {
		logger.info("********* SERVICE checkLoginAuth ****************");
		try {
			return foodDao.getCategoryList();
		} catch (Exception e) {
			logger.error("ERROR======>>>>", e);
			return null;
		}

	}

	@Override
	public List<ItemDto> getItemListAccordingToCategoryId(int categoryId) {
		logger.info("********* SERVICE getItemListAccordingToCategoryId ****************");
		try {
			return foodDao.getItemListAccordingToCategoryId(categoryId);
		} catch (Exception e) {
			logger.error("ERROR======>>>>", e);
			return null;
		}
	}

	@Override
	public int insertOwnerRequirement(OwnerInfo ownerInfo) {
		logger.info("********* SERVICE insertOwnerRequirement ****************");
		DataSourceTransactionManager transactionManager = new DataSourceTransactionManager(
				dataSource);
		TransactionDefinition def = new DefaultTransactionDefinition(
				TransactionDefinition.PROPAGATION_REQUIRES_NEW);
		TransactionStatus status = transactionManager.getTransaction(def);
		int resultId = 0;
		try {
			resultId = foodDao.insertOwnerRequirement(ownerInfo);
			if (resultId < 1) {
				transactionManager.rollback(status);
				return 0;
			}
			if (ownerInfo.getAttachmentList() != null
					&& ownerInfo.getAttachmentList().size() > 0) {
				int attachmentInsertionResult = foodDao
						.insertOwnerRequirementAttachment(resultId,
								ownerInfo.getAttachmentList());
				if (attachmentInsertionResult != ownerInfo.getAttachmentList()
						.size()) {
					transactionManager.rollback(status);
					return 0;
				}
			}

			transactionManager.commit(status);
		} catch (Exception e) {
			logger.error("ERROR======>>>>", e);
			return 0;
		}
		return resultId;

	}

}
