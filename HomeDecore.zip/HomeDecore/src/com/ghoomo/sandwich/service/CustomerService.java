package com.ghoomo.sandwich.service;

import java.util.List;

import com.ghoomo.sandwich.dto.CSCDto;
import com.ghoomo.sandwich.dto.CustomerDto;

public interface CustomerService {

	int customerInsertion(CustomerDto customerInfo);

	CustomerDto checkLoginAuth(CustomerDto customerInfo);

	int isCountryExist(int countryId);

	int isStateExistCorrespondingToCountry(int countryId, int stateId);

	int isCityExistCorrespondingToState(int cityId, int stateId);

	List<CSCDto> getCountryList();

	List<CSCDto> getStateListCorrespondingToCountry(int countryId);

	List<CSCDto> getCityListCorrespondingToState(int stateId);

}
