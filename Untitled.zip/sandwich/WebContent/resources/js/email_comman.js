function loadJS() {

	$(document).ready(
			function() {
				var selectedItems = 0;
				$('.clickable').click(function() {
					$('#inbox-wrapper').addClass('animated fadeOut');
					$('#inbox-wrapper').hide();
					$('#preview-email-wrapper').addClass('animated fadeIn ');
					$('#preview-email-wrapper').show();
					$('.page-title').show();
					$('#inbox-wrapper').removeClass('animated fadeOut');
					$('#inbox-wrapper').removeClass('animated fadeIn');
				});
				$('#btn-back').click(
						function() {
							$('#inbox-wrapper').addClass('animated fadeIn');
							$('#inbox-wrapper').show();
							$('#preview-email-wrapper').addClass(
									'animated fadeOut');
							$('#preview-email-wrapper').hide();
							$('.page-title').hide();
							$('#preview-email-wrapper').removeClass(
									'animated fadeIn ');
							$('#preview-email-wrapper').removeClass(
									'animated fadeOut ');
						});
				$('#email-list .checkbox input').click(
						function() {
							if ($(this).is(':checked')) {
								selectedItems++;
								$("#quick-access").css("bottom", "0px");
								$(this).parent().parent().parent().toggleClass(
										'row_selected');
							} else {
								selectedItems--;
								$("#quick-access").css("bottom", "0px");
								$(this).parent().parent().parent().toggleClass(
										'row_selected');
							}
							if (selectedItems == 0) {
								$("#quick-access").css("bottom", "-115px");
							}
						});
				$('.page-content').css('margin-left', '50');
				$('#quick-access .btn-cancel').click(
						function() {
							$("#quick-access").css("bottom", "-115px");
							$('#email-list .checkbox').children('input').attr(
									'checked', false);
							$("#emails tbody tr").removeClass('row_selected');
						});
			});

}