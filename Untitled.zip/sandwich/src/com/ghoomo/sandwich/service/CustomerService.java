package com.ghoomo.sandwich.service;

import java.util.List;

import com.ghoomo.sandwich.dto.CityDto;
import com.ghoomo.sandwich.dto.CountryDto;
import com.ghoomo.sandwich.dto.CustomerDto;
import com.ghoomo.sandwich.dto.StateDto;

public interface CustomerService {

	int customerInsertion(CustomerDto customerInfo);

	CustomerDto checkLoginAuth(CustomerDto customerInfo);

	int isCountryExist(int countryId);

	int isStateExistCorrespondingToCountry(int countryId, int stateId);

	int isCityExistCorrespondingToState(int cityId, int stateId);

	List<CountryDto> getCountryList();

	List<StateDto> getStateListCorrespondingToCountry(int countryId);

	List<CityDto> getCityListCorrespondingToState(int stateId);


}
