package com.ghoomo.sandwich.service;

import java.util.List;

import com.ghoomo.sandwich.dto.CategoryDto;
import com.ghoomo.sandwich.dto.ItemDto;
import com.ghoomo.sandwich.dto.OwnerInfo;

public interface FoodService {

	List<CategoryDto> getCategoryList();

	List<ItemDto> getItemListAccordingToCategoryId(int categoryId);

	int insertOwnerRequirement(OwnerInfo ownerInfo);

}
