package com.ghoomo.sandwich.restservice;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ghoomo.sandwich.constant.AppConstant;
import com.ghoomo.sandwich.constant.RestClintPath;
import com.ghoomo.sandwich.dto.CityDto;
import com.ghoomo.sandwich.dto.CityResponse;
import com.ghoomo.sandwich.dto.CountryDto;
import com.ghoomo.sandwich.dto.CountryResponse;
import com.ghoomo.sandwich.dto.Response;
import com.ghoomo.sandwich.dto.StateDto;
import com.ghoomo.sandwich.dto.StateResponse;
import com.ghoomo.sandwich.service.CustomerService;
import com.ghoomo.sandwich.utility.PropertiesUtil;

@Service
@Path(RestClintPath.CSC)
public class CSCRestService {
	
	static Logger logger = Logger.getLogger(CSCRestService.class);
	
	@Autowired
	private CustomerService customerService;
	
	@GET
	@Path(RestClintPath.GET_COUNTRY)
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	public Object getCountry(@Context HttpServletRequest request) {
		logger.info("********* API getCountry ****************");
//		CustomerDto customerInfo=(CustomerDto)request.getAttribute(AppConstant.LOGIN_CUSTOMER);
		List<CountryDto> countryList=customerService.getCountryList();
		
		if(countryList==null || countryList.size()==0){
			Response response=new Response();
			response.setMessage(PropertiesUtil
					.getProperty(AppConstant.DATA_NOT_FOUND_RESPONSE_MESSAGE));
			response.setSuccess(AppConstant.SUCCESS_FALSE);
			return response;
		}
		CountryResponse countryResponse=new CountryResponse();
		countryResponse.setMessage(PropertiesUtil
				.getProperty(AppConstant.DATA_FOUND_RESPONSE_MESSAGE));
		countryResponse.setSuccess(AppConstant.SUCCESS_TRUE);
		countryResponse.setCountryData(countryList);
		return countryResponse;
		
	}
	
	@GET
	@Path(RestClintPath.GET_STATE)
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	public Object getStateList(@Context HttpServletRequest request,@QueryParam("countryId") int countryId) {
		logger.info("********* API getStateList ****************");
//		CustomerDto customerInfo=(CustomerDto)request.getAttribute(AppConstant.LOGIN_CUSTOMER);
		List<StateDto> stateList=customerService.getStateListCorrespondingToCountry(countryId);
		
		if(stateList==null || stateList.size()==0){
			Response response=new Response();
			response.setMessage(PropertiesUtil
					.getProperty(AppConstant.DATA_NOT_FOUND_RESPONSE_MESSAGE));
			response.setSuccess(AppConstant.SUCCESS_FALSE);
			return response;
		}
		StateResponse response=new StateResponse();
		response.setMessage(PropertiesUtil
				.getProperty(AppConstant.DATA_FOUND_RESPONSE_MESSAGE));
		response.setSuccess(AppConstant.SUCCESS_TRUE);
		response.setStateData(stateList);
		return response;
		
	}
	
	@GET
	@Path(RestClintPath.GET_CITY)
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	public Object getCityList(@Context HttpServletRequest request,@QueryParam("stateId") int stateId) {
		logger.info("********* API getCityList ****************");
//		CustomerDto customerInfo=(CustomerDto)request.getAttribute(AppConstant.LOGIN_CUSTOMER);
		List<CityDto> cityList=customerService.getCityListCorrespondingToState(stateId);
		if(cityList==null || cityList.size()==0){
			Response response=new Response();
			response.setMessage(PropertiesUtil
					.getProperty(AppConstant.DATA_NOT_FOUND_RESPONSE_MESSAGE));
			response.setSuccess(AppConstant.SUCCESS_FALSE);
			return response;
		}
		CityResponse response=new CityResponse();
		response.setMessage(PropertiesUtil
				.getProperty(AppConstant.DATA_FOUND_RESPONSE_MESSAGE));
		response.setSuccess(AppConstant.SUCCESS_TRUE);
		response.setCityData(cityList);
		return response;
		
	}
}
