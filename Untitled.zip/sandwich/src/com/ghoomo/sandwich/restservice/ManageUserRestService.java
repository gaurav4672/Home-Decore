package com.ghoomo.sandwich.restservice;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ghoomo.sandwich.constant.AppConstant;
import com.ghoomo.sandwich.constant.RestClintPath;
import com.ghoomo.sandwich.dto.CustomerDto;
import com.ghoomo.sandwich.dto.CustomerResponse;
import com.ghoomo.sandwich.dto.Response;
import com.ghoomo.sandwich.service.CustomerService;
import com.ghoomo.sandwich.utility.PropertiesUtil;
import com.ghoomo.sandwich.utility.TokenUtility;
import com.ghoomo.sandwich.validation.sandwichValidation;

@Service
@Path(RestClintPath.MANAGE_USER)
public class ManageUserRestService {
	static Logger logger = Logger.getLogger(ManageUserRestService.class);

	@Autowired
	private CustomerService customerService;

	@POST
	@Path(RestClintPath.CREATE_CUSTOMER)
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	public Response createCustomer(CustomerDto customerInfo) {
		logger.info("********* API createCustomer ****************");
		Response response = new Response();
		String validationResult = sandwichValidation.customerValidation(customerInfo);
		if (validationResult != null) {
			response.setMessage(validationResult);
			response.setSuccess(AppConstant.SUCCESS_FALSE);
			return response;
		}

		if (customerService.isCountryExist(customerInfo.getCountryData().getCountryId()) == 0) {
			response.setMessage(PropertiesUtil.getProperty(AppConstant.COUNTRY_VALIDATION));
			response.setSuccess(AppConstant.SUCCESS_FALSE);
			return response;
		}
		if (customerService.isStateExistCorrespondingToCountry(customerInfo.getCountryData().getCountryId(),
				customerInfo.getStateData().getStateId()) == 0) {
			response.setMessage(PropertiesUtil.getProperty(AppConstant.STATE_VALIDATION));
			response.setSuccess(AppConstant.SUCCESS_FALSE);
			return response;
		}

		if (customerService.isCityExistCorrespondingToState(customerInfo.getCityData().getCityId(),
				customerInfo.getStateData().getStateId()) == 0) {
			response.setMessage(PropertiesUtil.getProperty(AppConstant.CITY_VALIDATION));
			response.setSuccess(AppConstant.SUCCESS_FALSE);
			return response;
		}

		int customerInsertionResult = customerService.customerInsertion(customerInfo);
		if (customerInsertionResult > 0) {
			CustomerResponse customerResponse = new CustomerResponse();
			customerResponse.setMessage(PropertiesUtil.getProperty(AppConstant.USER_REGISTERED_SUCCESSFULLY));
			customerResponse.setSuccess(AppConstant.SUCCESS_TRUE);
			CustomerDto customerDto = customerService.checkLoginAuth(customerInfo);
			customerResponse.setCustomerData(customerDto);
			return customerResponse;
		} else if (customerInsertionResult == -1) {
			response.setMessage(PropertiesUtil.getProperty(AppConstant.ACCOUNT_ALREADY_EXIST_MESSAGE));
			response.setSuccess(AppConstant.SUCCESS_FALSE);
			return response;
		} else {
			response.setMessage(PropertiesUtil.getProperty(AppConstant.INETERNAL_SERVER_ERROR_MESSAGE));
			response.setSuccess(AppConstant.SUCCESS_FALSE);
			return response;
		}
	}

	@POST
	@Path(RestClintPath.LOGIN_CUSTOMER)
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	public Object loginCustomer(CustomerDto customerInfo) {
		logger.info("********* API loginCustomer ****************");
		String customerLoginValidation = sandwichValidation.customerLoginValidation(customerInfo);
		Response response = new Response();
		if (customerLoginValidation != null) {
			response.setMessage(customerLoginValidation);
			response.setSuccess(AppConstant.SUCCESS_FALSE);
			return response;
		}
		CustomerDto customerDto = customerService.checkLoginAuth(customerInfo);
		if (customerDto == null || customerDto.getCustomerId() < 1) {
			response.setMessage(PropertiesUtil.getProperty(AppConstant.LOGIN_DETAILS_NOT_VALID_MESSAGE));
			response.setSuccess(AppConstant.SUCCESS_FALSE);
			return response;
		}
		if (customerDto.getIsActive() == 0) {
			response.setMessage(PropertiesUtil.getProperty(AppConstant.CUSTOMER_DEACTIVATE_MESSAGE));
			response.setSuccess(AppConstant.SUCCESS_FALSE);
			return response;
		}
		customerDto.setLoginToken(TokenUtility.createToken(customerDto));
		CustomerResponse customerResponse=new CustomerResponse();
		customerResponse.setMessage(PropertiesUtil.getProperty(AppConstant.LOGIN_SUCCESSFULLY));
		customerResponse.setSuccess(AppConstant.SUCCESS_TRUE);
		customerResponse.setCustomerData(customerDto);
		return customerResponse;
	}

}
