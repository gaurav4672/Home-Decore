package com.ghoomo.sandwich.restservice;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ghoomo.sandwich.constant.AppConstant;
import com.ghoomo.sandwich.constant.RestClintPath;
import com.ghoomo.sandwich.dto.CustomerDto;
import com.ghoomo.sandwich.dto.OwnerInfo;
import com.ghoomo.sandwich.dto.Response;
import com.ghoomo.sandwich.service.CustomerService;
import com.ghoomo.sandwich.service.FoodService;
import com.ghoomo.sandwich.utility.PropertiesUtil;

@Service
@Path(RestClintPath.MANAGE_OWNER_REQUIREMENT_SERVICE)
public class ManageOwnerRequirementRestService {
	
	static Logger logger = Logger.getLogger(ManageOwnerRequirementRestService.class);
	
	@Autowired
	private FoodService foodService;
	
	@Autowired
	private CustomerService customerService;

	@POST
	@Path(RestClintPath.INSERT_OWNER_REQUIREMENT)
	@Consumes({ MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_JSON })
	public Object loginCustomer(OwnerInfo ownerInfo,@Context HttpServletRequest request) {
		logger.info("********* API loginCustomer ****************");
		CustomerDto customerDto=(CustomerDto) request.getAttribute(AppConstant.LOGIN_CUSTOMER);
		Response response = new Response();
		if (customerService.isCountryExist(ownerInfo.getCountryData().getCountryId()) == 0) {
			response.setMessage(PropertiesUtil.getProperty(AppConstant.COUNTRY_VALIDATION));
			response.setSuccess(AppConstant.SUCCESS_FALSE);
			return response;
		}
		if (customerService.isStateExistCorrespondingToCountry(ownerInfo.getCountryData().getCountryId(),
				ownerInfo.getStateData().getStateId()) == 0) {
			response.setMessage(PropertiesUtil.getProperty(AppConstant.STATE_VALIDATION));
			response.setSuccess(AppConstant.SUCCESS_FALSE);
			return response;
		}

		if (customerService.isCityExistCorrespondingToState(ownerInfo.getCityData().getCityId(),
				ownerInfo.getStateData().getStateId()) == 0) {
			response.setMessage(PropertiesUtil.getProperty(AppConstant.CITY_VALIDATION));
			response.setSuccess(AppConstant.SUCCESS_FALSE);
			return response;
		}
		ownerInfo.setOwnerId(customerDto.getCustomerId());
		int insertResult=foodService.insertOwnerRequirement(ownerInfo);
		if(insertResult==0){
			response.setMessage(PropertiesUtil.getProperty(AppConstant.INSERT_FAILED));
			response.setSuccess(AppConstant.SUCCESS_FALSE);
			return response;
		}
		response.setMessage(PropertiesUtil.getProperty(AppConstant.INSERT_SUCCESSFULLY));
		response.setSuccess(AppConstant.SUCCESS_TRUE);
		return response;
	}
	

}
