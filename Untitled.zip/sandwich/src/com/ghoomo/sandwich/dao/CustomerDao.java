package com.ghoomo.sandwich.dao;

import java.util.List;

import com.ghoomo.sandwich.dto.CityDto;
import com.ghoomo.sandwich.dto.CountryDto;
import com.ghoomo.sandwich.dto.CustomerDto;
import com.ghoomo.sandwich.dto.StateDto;

public interface CustomerDao {

	int customerInsertion(CustomerDto customerInfo) throws Exception;

	CustomerDto checkLoginAuth(CustomerDto customerInfo) throws Exception;

	int isCountryExist(int countryId) throws Exception;

	int isStateExistCorrespondingToCountry(int countryId, int stateId)
			throws Exception;

	int isCityExistCorrespondingToState(int cityId, int stateId)
			throws Exception;

	


	List<CountryDto> getCountryList() throws Exception;

	List<StateDto> getStateListCorrespondingToCountry(int countryId) throws Exception;

	List<CityDto> getCityListCorrespondingToState(int stateId) throws Exception;

}
