package com.ghoomo.sandwich.dao;

import java.util.List;

import com.ghoomo.sandwich.dto.Attachment;
import com.ghoomo.sandwich.dto.CategoryDto;
import com.ghoomo.sandwich.dto.ItemDto;
import com.ghoomo.sandwich.dto.OwnerInfo;

public interface FoodDao {

	/**
	 * 
	 * User:- Gaurav Mangal Date:- 04-Jan-2017 Time:- 11:03:47 pm Method Name:-
	 * getCategoryList Type:- FoodDao Tags:- @return Tags:- @throws Exception
	 * Description:- This method is used to
	 */
	List<CategoryDto> getCategoryList() throws Exception;

	/**
	 * 
	 * User:- Gaurav Mangal Date:- 04-Jan-2017 Time:- 11:03:39 pm Method Name:-
	 * getItemListAccordingToCategoryId Type:- FoodDao Tags:- @param categoryId
	 * Tags:- @return Tags:- @throws Exception Description:- This method is used
	 * to
	 */
	List<ItemDto> getItemListAccordingToCategoryId(int categoryId) throws Exception;

	/**
	 * 
	 * User:- Gaurav Mangal Date:- 04-Jan-2017 Time:- 11:03:34 pm Method Name:-
	 * insertOwnerRequirement Type:- FoodDao Tags:- @param ownerInfo
	 * Tags:- @return Tags:- @throws Exception Description:- This method is used
	 * to
	 */
	int insertOwnerRequirement(OwnerInfo ownerInfo) throws Exception;

	/**
	 * 
	 * User:- Gaurav Mangal Date:- 04-Jan-2017 Time:- 11:03:04 pm Method Name:-
	 * insertOwnerRequirementAttachment Type:- FoodDao Tags:- @param ownerId
	 * Tags:- @param attachmentList Tags:- @return Tags:- @throws Exception
	 * Description:- This method is used to
	 */
	int insertOwnerRequirementAttachment(int ownerId, List<Attachment> attachmentList) throws Exception;

}
