package com.ghoomo.sandwich.constant;

public class AppAttribute {
	public final static String USER_TYPE = "userType";
	public final static String COUNTRY_LIST = "countryList";
	public final static String COUNTRY_ID = "countryId";
	public final static String STATE_ID = "stateId";
}
