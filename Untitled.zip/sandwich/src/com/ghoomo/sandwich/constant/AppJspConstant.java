package com.ghoomo.sandwich.constant;

public class AppJspConstant {
	public final static String LOGIN = "LOGIN";
	public final static String HOME = "HOME";
	public final static String REGISTER = "REGISTER";
}
