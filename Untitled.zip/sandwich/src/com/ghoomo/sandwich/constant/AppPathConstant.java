package com.ghoomo.sandwich.constant;

/**
 * 
 * @author Gaurav Mangal
 *
 */
public class AppPathConstant {

	public final static String LOGIN = "login.html";
	public final static String CHECK_AUTH = "checkAuth.html";
	public final static String HOME = "home.html";
	public final static String REDIRECT = "redirect:";
	public final static String LOGOUT = "logout.html";
	public final static String REGISTER = "register.html";
	public final static String SAVE_USER_DATA = "saveUserData.html";
	public final static String GET_STATE_LIST = "getStateList.html";
	public final static String GET_CITY_LIST = "getCityList.html";
}
