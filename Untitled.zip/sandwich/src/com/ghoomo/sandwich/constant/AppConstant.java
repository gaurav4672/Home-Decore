package com.ghoomo.sandwich.constant;

public class AppConstant {

	public final static String EMAIL_REJEX = "EMAIL_REJEX";
	public final static String CUSTOMER_NAME_VALIDATION = "CUSTOMER_NAME_VALIDATION";
	public final static String MOBILE_VALIDATION = "MOBILE_VALIDATION";
	public final static String EMAIL_VALIDATION = "EMAIL_VALIDATION";
	public final static String PASSWORD_VALIDATION = "PASSWORD_VALIDATION";
	public final static String VALIDATION_FAILED_RESPONSE_CODE = "VALIDATION_FAILED_RESPONSE_CODE";
	public final static String COMPLETE_REQUEST_RESPONSE_CODE = "COMPLETE_REQUEST_RESPONSE_CODE";
	public final static String ACCOUNT_ALREADY_EXIST_MESSAGE = "ACCOUNT_ALREADY_EXIST_MESSAGE";
	public final static String INETERNAL_SERVER_ERROR_CODE = "INETERNAL_SERVER_ERROR_CODE";
	public final static String INETERNAL_SERVER_ERROR_MESSAGE = "INETERNAL_SERVER_ERROR_MESSAGE";
	public final static String PERMANENT_IMAGE_PATH = "PERMANENT_IMAGE_PATH";
	public final static String IMAGE_URL = "IMAGE_URL";
	public final static String BLANK_LOGIN_ID = "BLANK_LOGIN_ID";
	public final static String BLANK_LOGIN_PASSWORD = "BLANK_LOGIN_PASSWORD";
	public final static String DATA_NOT_FOUND_RESPONSE_CODE = "DATA_NOT_FOUND_RESPONSE_CODE";
	public final static String LOGIN_DETAILS_NOT_VALID_MESSAGE = "LOGIN_DETAILS_NOT_VALID_MESSAGE";
	public final static String CUSTOMER_DEACTIVATE_MESSAGE = "CUSTOMER_DEACTIVATE_MESSAGE";
	public final static String LOGIN_CUSTOMER = "LOGIN_CUSTOMER";
	public static final String RESPONSE = "RESPONSE";
	public static final String INVAIL_PERAMETER_VALUE = "INVAIL_PERAMETER_VALUE";
	public static final String RESPONSE_CODE = "RESPONSE_CODE";
	public static final String INVAIL_PERAMETER_VALUE_CODE = "INVAIL_PERAMETER_VALUE_CODE";
	public static final String UNAUTHORIZED = "UNAUTHORIZED";
	public static final String UNAUTHORIZED_CODE = "UNAUTHORIZED_CODE";
	public static final int DELETED = 1;
	public static final int NON_DELETED = 0;
	public final static String DATA_NOT_FOUND_RESPONSE_MESSAGE = "DATA_NOT_FOUND_RESPONSE_MESSAGE";
	public final static String COUNTRY_VALIDATION = "COUNTRY_VALIDATION";
	public final static String STATE_VALIDATION = "STATE_VALIDATION";
	public final static String CITY_VALIDATION = "CITY_VALIDATION";
	public final static boolean SUCCESS_FALSE = false;
	public final static boolean SUCCESS_TRUE = true;
	public final static String USER_REGISTERED_SUCCESSFULLY = "USER_REGISTERED_SUCCESSFULLY";
	public final static String LOGIN_SUCCESSFULLY = "LOGIN_SUCCESSFULLY";
	public final static String DATA_FOUND_RESPONSE_MESSAGE = "DATA_FOUND_RESPONSE_MESSAGE";
	public final static String INSERT_FAILED = "INSERT_FAILED";
	public final static String INSERT_SUCCESSFULLY = "INSERT_SUCCESSFULLY";
	public final static String REGISTER_CONTRACTOR = "REGISTER_CONTRACTOR";
	public final static String REGISTER_OWNER = "REGISTER_OWNER";
}
