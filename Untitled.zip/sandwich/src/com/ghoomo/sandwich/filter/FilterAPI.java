package com.ghoomo.sandwich.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;

import com.ghoomo.sandwich.constant.AppConstant;
import com.ghoomo.sandwich.dto.CustomerDto;
import com.ghoomo.sandwich.utility.PropertiesUtil;
import com.ghoomo.sandwich.utility.TokenUtility;

public class FilterAPI implements Filter {

	static Logger logger = Logger.getLogger(FilterAPI.class);

	@Override
	public void destroy() {
		logger.debug("======================= MyFilter destroy() API =======================");
	}

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1,
			FilterChain arg2) throws IOException, ServletException {

		HttpServletRequest req = (HttpServletRequest) arg0;
		HttpServletResponse resp = (HttpServletResponse) arg1;
		String token = req.getHeader("AUTH_TOKEN");
		logger.info("AUTH_TOKEN::::::::::::-" + token);
		if (token != null && token.trim().length() > 0) {
			logger.debug("Check Req Object isNull :-" + (req == null));
			// Updated By Gaurav Mangal on 20-01-2016.
			// boolean isValidToken=TokenUtility.checkValidToken(token);
			CustomerDto customerDto = TokenUtility.checkValidToken(token);
			if (customerDto != null && customerDto.getCustomerId() > 0) {
				try {
					req.setAttribute(AppConstant.LOGIN_CUSTOMER, customerDto);
					logger.debug("Check Req Object isNull :-" + (req == null));
					arg2.doFilter(arg0, arg1);
					logger.debug("Check Req Object isNull :-" + (req == null));
				} catch (NumberFormatException e) {
					logger.error("Error NumberFormatException ======>>>>>> ", e);
					JSONObject json = new JSONObject();
					try {

						json.put(
								PropertiesUtil
										.getProperty(AppConstant.RESPONSE),
								PropertiesUtil
										.getProperty(AppConstant.INVAIL_PERAMETER_VALUE));
						json.put(
								PropertiesUtil
										.getProperty(AppConstant.RESPONSE_CODE),
								PropertiesUtil
										.getProperty(AppConstant.INVAIL_PERAMETER_VALUE_CODE));

					} catch (JSONException ex) {
						logger.error("Error ======>>>>>> ", ex);
					}
					resp.getWriter().write(json.toString());
				} catch (javax.ws.rs.WebApplicationException e) {
					logger.error(
							"Error javax.ws.rs.WebApplicationException ======>>>>>> ",
							e);
					JSONObject json = new JSONObject();
					try {

						json.put(
								PropertiesUtil
										.getProperty(AppConstant.RESPONSE),
								PropertiesUtil
										.getProperty(AppConstant.INVAIL_PERAMETER_VALUE));
						json.put(
								PropertiesUtil
										.getProperty(AppConstant.RESPONSE_CODE),
								PropertiesUtil
										.getProperty(AppConstant.INVAIL_PERAMETER_VALUE_CODE));

					} catch (JSONException ex) {
						logger.error("Error ======>>>>>> ", ex);
					}
					resp.getWriter().write(json.toString());
				} catch (Exception e) {
					logger.error("Error ======>>>>>> ", e);
					JSONObject json = new JSONObject();
					try {

						json.put(
								PropertiesUtil
										.getProperty(AppConstant.RESPONSE),
								PropertiesUtil
										.getProperty(AppConstant.INVAIL_PERAMETER_VALUE));
						json.put(
								PropertiesUtil
										.getProperty(AppConstant.RESPONSE_CODE),
								PropertiesUtil
										.getProperty(AppConstant.INVAIL_PERAMETER_VALUE_CODE));

					} catch (JSONException ex) {
						logger.error("Error ======>>>>>> ", ex);
					}
					resp.getWriter().write(json.toString());
				}
			} else {
				JSONObject json = new JSONObject();
				try {

					json.put(PropertiesUtil.getProperty(AppConstant.RESPONSE),
							PropertiesUtil
									.getProperty(AppConstant.UNAUTHORIZED));
					json.put(
							PropertiesUtil
									.getProperty(AppConstant.RESPONSE_CODE),
							PropertiesUtil
									.getProperty(AppConstant.UNAUTHORIZED_CODE));

				} catch (JSONException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					logger.error("Error ======>>>>>> ", e);
				}
				resp.getWriter().write(json.toString());
			}
		} else {
			JSONObject json = new JSONObject();
			try {

				json.put("response", "Unauthorized");
				json.put("responseCode", "3009");

			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.error("Error ======>>>>>> ", e);
			}
			resp.getWriter().write(json.toString());
		}
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		logger.debug("========================= MyFilter init() API =========================");
	}

}
