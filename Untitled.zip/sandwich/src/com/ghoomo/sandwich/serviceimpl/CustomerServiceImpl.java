package com.ghoomo.sandwich.serviceimpl;

import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import com.ghoomo.sandwich.dao.CustomerDao;
import com.ghoomo.sandwich.dto.CityDto;
import com.ghoomo.sandwich.dto.CountryDto;
import com.ghoomo.sandwich.dto.CustomerDto;
import com.ghoomo.sandwich.dto.StateDto;
import com.ghoomo.sandwich.service.CustomerService;

public class CustomerServiceImpl implements CustomerService {

	static Logger logger = Logger.getLogger(CustomerServiceImpl.class);

	@Autowired
	private DataSource dataSource;

	@Autowired
	private CustomerDao customerDao;

	@Override
	public int customerInsertion(final CustomerDto customerInfo) {
		logger.info("********* SERVICE customerInsertion ****************");
		DataSourceTransactionManager transactionManager = new DataSourceTransactionManager(dataSource);
		TransactionDefinition def = new DefaultTransactionDefinition(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
		TransactionStatus status = transactionManager.getTransaction(def);
		try {
			int customerInsertionResult = customerDao.customerInsertion(customerInfo);
			if (customerInsertionResult > 0) {
				transactionManager.commit(status);
				return customerInsertionResult;
			} else {
				transactionManager.rollback(status);
				return 0;
			}
		} catch (DuplicateKeyException duplicateKeyException) {
			logger.error("ERROR======>>>>", duplicateKeyException);
			transactionManager.rollback(status);
			return -1;
		}

		catch (Exception e) {
			logger.error("ERROR======>>>>", e);
			transactionManager.rollback(status);
			return 0;
		}

	}

	@Override
	public CustomerDto checkLoginAuth(CustomerDto customerInfo) {
		logger.info("********* SERVICE checkLoginAuth ****************");
		try {
			return customerDao.checkLoginAuth(customerInfo);
		} catch (Exception e) {
			logger.error("ERROR======>>>>", e);
			return null;
		}
	}

	@Override
	public int isCountryExist(int countryId) {
		logger.info("********* SERVICE isCountryExist ****************");
		try {
			return customerDao.isCountryExist(countryId);
		} catch (Exception e) {
			logger.error("ERROR======>>>>", e);
			return 0;
		}
	}

	@Override
	public int isStateExistCorrespondingToCountry(int countryId, int stateId) {
		logger.info("********* SERVICE isStateExistCorrespondingToCountry ****************");
		try {
			return customerDao.isStateExistCorrespondingToCountry(countryId, stateId);
		} catch (Exception e) {
			logger.error("ERROR======>>>>", e);
			return 0;
		}
	}

	@Override
	public int isCityExistCorrespondingToState(int cityId, int stateId) {
		logger.info("********* SERVICE isCityExistCorrespondingToState ****************");
		try {
			return customerDao.isCityExistCorrespondingToState(cityId, stateId);
		} catch (Exception e) {
			logger.error("ERROR======>>>>", e);
			return 0;
		}
	}

	@Override
	public List<CountryDto> getCountryList() {
		logger.info("********* SERVICE getCountryList ****************");
		try {
			return customerDao.getCountryList();
		} catch (Exception e) {
			logger.error("ERROR======>>>>", e);
			return null;
		}
	}

	@Override
	public List<StateDto> getStateListCorrespondingToCountry(int countryId) {
		logger.info("********* SERVICE getStateListCorrespondingToCountry ****************");
		try {
			return customerDao.getStateListCorrespondingToCountry(countryId);
		} catch (Exception e) {
			logger.error("ERROR======>>>>", e);
			return null;
		}
	}

	@Override
	public List<CityDto> getCityListCorrespondingToState(int stateId) {
		logger.info("********* SERVICE getCityListCorrespondingToState ****************");
		try {
			return customerDao.getCityListCorrespondingToState(stateId);
		} catch (Exception e) {
			logger.error("ERROR======>>>>", e);
			return null;
		}
	}
}
