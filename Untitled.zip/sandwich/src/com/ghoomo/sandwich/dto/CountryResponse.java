package com.ghoomo.sandwich.dto;

import java.util.List;

public class CountryResponse extends Response {
	private List<CountryDto> countryData;

	public List<CountryDto> getCountryData() {
		return countryData;
	}

	public void setCountryData(List<CountryDto> countryData) {
		this.countryData = countryData;
	}


	

}
