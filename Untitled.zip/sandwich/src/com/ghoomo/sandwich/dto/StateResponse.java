package com.ghoomo.sandwich.dto;

import java.util.List;

public class StateResponse extends Response {
	private List<StateDto> stateData;

	public List<StateDto> getStateData() {
		return stateData;
	}

	public void setStateData(List<StateDto> stateData) {
		this.stateData = stateData;
	}

	

}
