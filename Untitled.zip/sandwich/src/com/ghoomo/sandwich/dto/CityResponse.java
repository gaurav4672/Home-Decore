package com.ghoomo.sandwich.dto;

import java.util.List;

public class CityResponse extends Response {
	private List<CityDto> cityData;

	public List<CityDto> getCityData() {
		return cityData;
	}

	public void setCityData(List<CityDto> cityData) {
		this.cityData = cityData;
	}

	
}
