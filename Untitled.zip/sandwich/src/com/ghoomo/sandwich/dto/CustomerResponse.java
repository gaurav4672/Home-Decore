package com.ghoomo.sandwich.dto;

public class CustomerResponse extends Response {
	private CustomerDto customerData;

	public CustomerDto getCustomerData() {
		return customerData;
	}

	public void setCustomerData(CustomerDto customerData) {
		this.customerData = customerData;
	}
	

}
