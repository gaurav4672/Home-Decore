package com.ghoomo.sandwich.dto;

import java.util.List;

public class OwnerInfo {
	private int id;
	private int ownerId;
	private int requirementTypeId;
	private float estBudget;
	private String workStartDate;
	private String workEndDate;
	private String description;
	private CountryDto countryData;
	private StateDto  stateData;
	private CityDto cityData;
	private String createDate;
	private String updateDate;
	private String area;
	private List<Attachment> attachmentList;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}

	public int getRequirementTypeId() {
		return requirementTypeId;
	}

	public void setRequirementTypeId(int requirementTypeId) {
		this.requirementTypeId = requirementTypeId;
	}

	public float getEstBudget() {
		return estBudget;
	}

	public void setEstBudget(float estBudget) {
		this.estBudget = estBudget;
	}

	public String getWorkStartDate() {
		return workStartDate;
	}

	public void setWorkStartDate(String workStartDate) {
		this.workStartDate = workStartDate;
	}

	public String getWorkEndDate() {
		return workEndDate;
	}

	public void setWorkEndDate(String workEndDate) {
		this.workEndDate = workEndDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public List<Attachment> getAttachmentList() {
		return attachmentList;
	}

	public void setAttachmentList(List<Attachment> attachmentList) {
		this.attachmentList = attachmentList;
	}

	public CountryDto getCountryData() {
		return countryData;
	}

	public void setCountryData(CountryDto countryData) {
		this.countryData = countryData;
	}

	public StateDto getStateData() {
		return stateData;
	}

	public void setStateData(StateDto stateData) {
		this.stateData = stateData;
	}

	public CityDto getCityData() {
		return cityData;
	}

	public void setCityData(CityDto cityData) {
		this.cityData = cityData;
	}

}
