package com.ghoomo.sandwich.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.sql.DataSource;
import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import com.ghoomo.sandwich.constant.AppConstant;
import com.ghoomo.sandwich.constant.AppQueryConstant;
import com.ghoomo.sandwich.dao.CustomerDao;
import com.ghoomo.sandwich.dto.CityDto;
import com.ghoomo.sandwich.dto.CountryDto;
import com.ghoomo.sandwich.dto.CustomerDto;
import com.ghoomo.sandwich.dto.StateDto;
import com.ghoomo.sandwich.serviceimpl.CustomerServiceImpl;
import com.ghoomo.sandwich.utility.PropertiesUtil;

public class CustomerDaoImpl implements CustomerDao {

	static Logger logger = Logger.getLogger(CustomerServiceImpl.class);

	private JdbcTemplate jdbcTemplate;

	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public int customerInsertion(final CustomerDto customerInfo)
			throws Exception {
		logger.info("********* DAO customerInsertion ****************");
		final String sql = PropertiesUtil
				.getProperty(AppQueryConstant.CUSTOMER_INSERTION);
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator() {
			public PreparedStatement createPreparedStatement(
					Connection connection) throws SQLException {
				PreparedStatement ps = connection.prepareStatement(sql,
						new String[] { "id" });
				ps.setString(1, customerInfo.getName().trim());
				ps.setString(2, customerInfo.getEmail().trim());
				ps.setString(3, customerInfo.getMobile().trim());
				ps.setString(4, customerInfo.getPassword());
				ps.setInt(5, customerInfo.getCountryData().getCountryId());
				ps.setInt(6, customerInfo.getStateData().getStateId());
				ps.setInt(7, customerInfo.getCityData().getCityId());
				ps.setString(8, customerInfo.getFcmToken());
				ps.setInt(9, customerInfo.getUserType());
				return ps;
			}
		}, keyHolder);

		return keyHolder.getKey().intValue();
	}

	@Override
	public CustomerDto checkLoginAuth(CustomerDto customerInfo)
			throws Exception {
		logger.info("********* DAO checkLoginAuth ****************");
		logger.info("userName:::::::::::::" + customerInfo.getEmail());
		logger.info("Password:::::::::::::" + customerInfo.getPassword());
		String sql = PropertiesUtil
				.getProperty(AppQueryConstant.CHECK_LOGIN_AUTH);
		return jdbcTemplate.queryForObject(sql,
				new Object[] { customerInfo.getEmail(),
						customerInfo.getEmail(), customerInfo.getPassword() },
				new RowMapper<CustomerDto>() {

					@Override
					public CustomerDto mapRow(ResultSet rs, int arg1)
							throws SQLException {
						CustomerDto customerDto = new CustomerDto();
						customerDto.setCustomerId(rs.getInt("id"));
						customerDto.setName(rs.getString("name"));
						customerDto.setEmail(rs.getString("email"));
						customerDto.setMobile(rs.getString("mobile"));
						customerDto.setAddress(rs.getString("address"));
						customerDto.setCreateDateTime(rs
								.getString("create_date"));
						customerDto.setUpdateDateTime(rs
								.getString("update_date"));
						customerDto.setIsActive(rs.getInt("is_active"));
						if (rs.getString("profile_image") != null
								&& rs.getString("image").trim().length() > 0) {
							customerDto.setImage(PropertiesUtil
									.getProperty(AppConstant.IMAGE_URL)
									+ rs.getString("profile_image"));
						}
						customerDto.setLandline(rs.getString("landline"));
						customerDto.setCountryData(new CountryDto());
						customerDto.setStateData(new StateDto());
						customerDto.setCityData(new CityDto());
						customerDto.getCountryData().setCountryId(rs.getInt("country_id"));
						customerDto.getCountryData().setCountryName(rs.getString("country_name"));
						customerDto.getStateData().setStateId(rs.getInt("state_id"));
						customerDto.getStateData().setStateName(rs.getString("state_name"));
						customerDto.getCityData().setCityId(rs.getInt("city_id"));
						customerDto.getCityData().setCityName(rs.getString("city_name"));
						customerDto.setPostalcode(rs.getString("postal_code"));
						customerDto.setUserType(rs.getInt("user_type"));
						customerDto.setContExpYear(rs.getInt("cont_exp_year"));
						customerDto.setContExpMonth(rs.getInt("cont_exp_month"));
						customerDto.setOrganizatonName(rs.getString("organization_name"));
						customerDto.setIsDeleted(rs.getInt("is_deleted"));
						customerDto.setAlternateNumber(rs.getString("alternate_number"));
						customerDto.setSubscriptionId(rs.getInt("subcription_id"));
						customerDto.setFcmToken(rs.getString("fcm_token"));
						return customerDto;
					}

				});

	}

	@Override
	public int isCountryExist(int countryId) throws Exception {
		logger.info("********* DAO isCountryExist ****************");
		logger.info("countryId:::::::::::::" + countryId);
		String sql = PropertiesUtil
				.getProperty(AppQueryConstant.IS_COUNTRY_EXIST);
		return jdbcTemplate.queryForInt(sql, countryId);
	}

	@Override
	public int isStateExistCorrespondingToCountry(int countryId, int stateId)
			throws Exception {
		logger.info("********* DAO isStateExistCorrespondingToCountry ****************");
		logger.info("countryId:::::::::::::" + countryId);
		logger.info("stateId:::::::::::::" + stateId);
		String sql = PropertiesUtil
				.getProperty(AppQueryConstant.IS_STATE_EXIST_CORRESPONDING_TO_COUNTRY);
		return jdbcTemplate.queryForInt(sql, stateId, countryId);
	}

	@Override
	public int isCityExistCorrespondingToState(int cityId, int stateId)
			throws Exception {
		logger.info("********* DAO isCityExistCorrespondingToState ****************");
		logger.info("cityId:::::::::::::" + cityId);
		logger.info("stateId:::::::::::::" + stateId);
		String sql = PropertiesUtil
				.getProperty(AppQueryConstant.IS_CITY_EXIST_CORRESPONDING_TO_STATE);
		return jdbcTemplate.queryForInt(sql, cityId, stateId);
	}

	@Override
	public List<CountryDto> getCountryList() throws Exception {
		logger.info("********* DAO getCountryList ****************");
		String sql = PropertiesUtil
				.getProperty(AppQueryConstant.GET_COUNTRY_LIST);
		return jdbcTemplate.query(sql, new RowMapper<CountryDto>() {

			@Override
			public CountryDto mapRow(ResultSet rs, int arg1) throws SQLException {
				CountryDto cscDto = new CountryDto();
				cscDto.setCountryId(rs.getInt("id"));
				cscDto.setCountryName(rs.getString("name"));
				return cscDto;
			}

		});
	}

	@Override
	public List<StateDto> getStateListCorrespondingToCountry(int countryId)
			throws Exception {
		logger.info("********* DAO getStateListCorrespondingToCountry ****************");
		String sql = PropertiesUtil
				.getProperty(AppQueryConstant.GET_STATE_LIST_CORRESPONDING_TO_COUNTRY);
		return jdbcTemplate.query(sql, new Object[] { countryId },
				new RowMapper<StateDto>() {

					@Override
					public StateDto mapRow(ResultSet rs, int arg1)
							throws SQLException {
						StateDto cscDto = new StateDto();
						cscDto.setStateId(rs.getInt("id"));
						cscDto.setStateName(rs.getString("name"));
						return cscDto;
					}

				});
	}

	@Override
	public List<CityDto> getCityListCorrespondingToState(int stateId)
			throws Exception {
		logger.info("********* DAO getCityListCorrespondingToState ****************");
		String sql = PropertiesUtil
				.getProperty(AppQueryConstant.GET_CITY_LIST_CORRESPONDING_TO_STATE);
		return jdbcTemplate.query(sql, new Object[] { stateId },
				new RowMapper<CityDto>() {

					@Override
					public CityDto mapRow(ResultSet rs, int arg1)
							throws SQLException {
						CityDto cscDto = new CityDto();
						cscDto.setCityId(rs.getInt("id"));
						cscDto.setCityName(rs.getString("name"));
						return cscDto;
					}

				});
	}

}
