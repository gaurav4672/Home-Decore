package com.ghoomo.sandwich.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import com.ghoomo.sandwich.constant.AppConstant;
import com.ghoomo.sandwich.constant.AppQueryConstant;
import com.ghoomo.sandwich.dao.FoodDao;
import com.ghoomo.sandwich.dto.Attachment;
import com.ghoomo.sandwich.dto.CategoryDto;
import com.ghoomo.sandwich.dto.ItemDto;
import com.ghoomo.sandwich.dto.OwnerInfo;
import com.ghoomo.sandwich.serviceimpl.CustomerServiceImpl;
import com.ghoomo.sandwich.utility.PropertiesUtil;

public class FoodDaoImpl implements FoodDao {

	static Logger logger = Logger.getLogger(FoodDaoImpl.class);

	private JdbcTemplate jdbcTemplate;

	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public List<CategoryDto> getCategoryList() throws Exception {
		logger.info("********* DAO getCategoryList ****************");
		String sql = PropertiesUtil.getProperty(AppQueryConstant.GET_CATEGORY_LIST);
		return jdbcTemplate.query(sql, new Object[] { AppConstant.NON_DELETED }, new RowMapper<CategoryDto>() {

			@Override
			public CategoryDto mapRow(ResultSet rs, int arg1) throws SQLException {
				CategoryDto categoryDto = new CategoryDto();
				categoryDto.setCategoryId(rs.getInt("id"));
				categoryDto.setCategoryName(rs.getString("category_name"));
				if (rs.getString("image") != null && rs.getString("image").trim().length() > 0) {
					categoryDto.setCategoryImage(
							PropertiesUtil.getProperty(AppConstant.IMAGE_URL) + rs.getString("image"));
				}
				return categoryDto;
			}
		});
	}

	@Override
	public List<ItemDto> getItemListAccordingToCategoryId(int categoryId) throws Exception {
		logger.info("********* DAO getItemListAccordingToCategoryId ****************");
		String sql = PropertiesUtil.getProperty(AppQueryConstant.GET_ITEM_LIST_ACCORDING_TO_CATEGORY_ID);
		return jdbcTemplate.query(sql, new Object[] { AppConstant.NON_DELETED, categoryId }, new RowMapper<ItemDto>() {

			@Override
			public ItemDto mapRow(ResultSet rs, int arg1) throws SQLException {
				ItemDto itemInfo = new ItemDto();
				itemInfo.setItemId(rs.getInt("id"));
				itemInfo.setItemImage(rs.getString("item_name"));
				itemInfo.setItemPrice(rs.getFloat("price"));
				itemInfo.setItemWeight(rs.getDouble("weight"));
				itemInfo.setItemCalories(rs.getDouble("calories"));
				itemInfo.setIsVeg(rs.getInt("is_veg"));
				if (rs.getString("image") != null && rs.getString("image").trim().length() > 0) {
					itemInfo.setItemImage(PropertiesUtil.getProperty(AppConstant.IMAGE_URL) + rs.getString("image"));
				}
				return itemInfo;
			}
		});
	}

	@Override
	public int insertOwnerRequirement(final OwnerInfo ownerInfo) throws Exception {
		logger.info("********* DAO insertOwnerRequirement ****************");
		final String sql = PropertiesUtil.getProperty(AppQueryConstant.INSERT_OWNER_REQUIREMENT);
		KeyHolder keyHolder = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator() {
			public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
				PreparedStatement ps = connection.prepareStatement(sql, new String[] { "id" });
				ps.setInt(1, ownerInfo.getOwnerId());
				ps.setInt(2, ownerInfo.getRequirementTypeId());
				ps.setFloat(3, ownerInfo.getEstBudget());
				ps.setString(4, ownerInfo.getWorkStartDate());
				ps.setString(5, ownerInfo.getWorkEndDate());
				ps.setString(6, ownerInfo.getDescription());
				ps.setInt(7, ownerInfo.getCountryData().getCountryId());
				ps.setInt(8, ownerInfo.getStateData().getStateId());
				ps.setInt(9, ownerInfo.getCityData().getCityId());
				ps.setString(10, ownerInfo.getArea());
				return ps;
			}
		}, keyHolder);

		return keyHolder.getKey().intValue();
	}

	/**
	 * 
	 * User:- Gaurav Mangal Date:- 04-Jan-2017 Time:- 10:57:16 pm Method Name:-
	 * insertOwnerRequirementAttachment Type:- FoodDaoImpl Tags:- @param ownerId
	 * Tags:- @param attachmentList Tags:- @return Tags:- @throws Exception
	 * Description:- This method is used to
	 */
	@Override
	public int insertOwnerRequirementAttachment(final int ownerId, final List<Attachment> attachmentList)
			throws Exception {
		logger.info("********* DAO insertOwnerRequirementAttachment ****************");
		final String sql = PropertiesUtil.getProperty(AppQueryConstant.INSERT_OWNER_REQUIREMENT_ATTACHMENT);
		int result[] = jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {

			@Override
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				Attachment attachment = attachmentList.get(i);
				ps.setInt(1, ownerId);
				ps.setString(2, attachment.getFileName());
			}

			@Override
			public int getBatchSize() {
				return attachmentList.size();
			}

		});
		return result.length;
	}
}
